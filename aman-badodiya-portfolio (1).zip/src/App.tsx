import { motion } from 'motion/react';
import { 
  MapPin, 
  GraduationCap, 
  Terminal, 
  Coffee, 
  Monitor, 
  Wrench, 
  ChevronDown, 
  Code2, 
  User, 
  Briefcase,
  Sparkles,
  Linkedin,
  Mail,
  MessageSquare,
  Send
} from 'lucide-react';

export default function App() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5, ease: "easeOut" }
    },
  };

  return (
    <div className="min-h-screen font-sans selection:bg-emerald-500/30 selection:text-emerald-200 text-gray-100">
      {/* Background Image - Black Earth */}
      <div className="fixed inset-0 z-[-2] bg-[url('https://images.unsplash.com/photo-1614730321146-b6fa6a46bcb4?q=80&w=1920&auto=format&fit=crop')] bg-cover bg-center bg-no-repeat opacity-40 pointer-events-none" />
      <div className="fixed inset-0 z-[-1] bg-gray-950/70 pointer-events-none" />

      {/* Background Effects */}
      <div className="fixed inset-0 z-[-1] overflow-hidden pointer-events-none">
        <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] rounded-full bg-emerald-600/20 blur-[120px]" />
        <div className="absolute bottom-[-20%] right-[-10%] w-[50%] h-[50%] rounded-full bg-indigo-600/20 blur-[120px]" />
        <div className="absolute top-[40%] left-[40%] w-[20%] h-[20%] rounded-full bg-purple-600/20 blur-[100px]" />
      </div>

      {/* Navbar */}
      <nav className="fixed top-0 w-full z-50 backdrop-blur-md bg-gray-950/50 border-b border-white/5">
        <div className="max-w-5xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="font-mono font-bold text-xl tracking-tighter flex items-center gap-2">
            <Code2 className="w-6 h-6 text-emerald-400" />
            <span>Aman<span className="text-emerald-400">.</span>dev</span>
          </div>
          <div className="hidden md:flex gap-8 text-sm font-medium text-gray-400">
            <a href="#about" className="hover:text-emerald-400 hover:scale-110 transition-all duration-300">About</a>
            <a href="#skills" className="hover:text-emerald-400 hover:scale-110 transition-all duration-300">Skills</a>
            <a href="#education" className="hover:text-emerald-400 hover:scale-110 transition-all duration-300">Education</a>
            <a href="#contact" className="hover:text-emerald-400 hover:scale-110 transition-all duration-300">Contact</a>
          </div>
        </div>
      </nav>

      <main className="max-w-6xl mx-auto px-6 pt-32 pb-24">
        {/* Hero Section */}
        <motion.section 
          className="min-h-[85vh] grid lg:grid-cols-2 gap-12 items-center relative"
          initial="hidden"
          animate="visible"
          variants={containerVariants}
        >
          <div className="flex flex-col items-start z-10">
            <motion.div variants={itemVariants} className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-emerald-400 text-sm font-mono mb-6">
              <Sparkles className="w-4 h-4" />
              <span>Welcome to my portfolio</span>
            </motion.div>
            
            <motion.h1 variants={itemVariants} className="text-5xl md:text-7xl font-bold tracking-tight mb-4">
              Hi, I'm <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-400">Aman Badodiya</span>
            </motion.h1>
            
            <motion.h2 variants={itemVariants} className="text-2xl md:text-4xl text-gray-400 font-medium mb-6">
              Aspiring Full Stack Developer
            </motion.h2>
            
            <motion.div variants={itemVariants} className="flex items-center gap-2 text-gray-500 mb-10 font-mono">
              <MapPin className="w-5 h-5" />
              <span>Handia, Madhya Pradesh</span>
            </motion.div>
            
            <motion.div variants={itemVariants} className="flex gap-4">
              <a href="#about" className="px-6 py-3 rounded-lg bg-white text-gray-950 font-semibold hover:bg-gray-200 hover:scale-105 hover:shadow-[0_0_20px_rgba(255,255,255,0.3)] transition-all duration-300 flex items-center gap-2">
                <User className="w-5 h-5" />
                About Me
              </a>
              <a href="#skills" className="px-6 py-3 rounded-lg bg-white/5 border border-white/10 font-semibold hover:bg-white/10 hover:scale-105 hover:shadow-[0_0_20px_rgba(52,211,153,0.2)] hover:border-emerald-500/30 transition-all duration-300 flex items-center gap-2">
                <Terminal className="w-5 h-5" />
                View Skills
              </a>
            </motion.div>
          </div>

          <motion.div variants={itemVariants} className="relative w-full max-w-md mx-auto lg:max-w-none flex justify-center lg:justify-end">
            <div className="absolute inset-0 bg-gradient-to-tr from-emerald-500/20 to-cyan-500/20 blur-[100px] rounded-full" />
            <div className="relative w-72 h-72 md:w-80 md:h-80 rounded-full overflow-hidden border-[2.1px] border-white/10 shadow-[0_0_40px_rgba(52,211,153,0.2)] group">
              <img 
                src="/PSX_20250722_171842.jpg" 
                alt="Aman Badodiya" 
                className="w-full h-full object-cover object-[center_20%] scale-125 transition-transform duration-700 group-hover:scale-150"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 border-[2.1px] border-emerald-500/30 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            </div>
          </motion.div>

          <motion.div 
            variants={itemVariants}
            className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce text-gray-500 hidden md:block col-span-full"
          >
            <ChevronDown className="w-6 h-6" />
          </motion.div>
        </motion.section>

        {/* About Section */}
        <motion.section 
          id="about" 
          className="py-24 border-t border-white/5"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={containerVariants}
        >
          <motion.div variants={itemVariants} className="flex items-center gap-4 mb-12">
            <div className="w-12 h-12 rounded-xl bg-indigo-500/20 flex items-center justify-center text-indigo-400">
              <User className="w-6 h-6" />
            </div>
            <h2 className="text-3xl font-bold">About Me</h2>
          </motion.div>
          
          <div className="grid md:grid-cols-2 gap-12">
            <motion.div variants={itemVariants} className="space-y-6 text-gray-400 text-lg leading-relaxed">
              <p>
                Hello! I'm Aman, a 2nd-year BCA student with a strong passion for technology and software development. 
                I am constantly exploring new tools and frameworks to expand my knowledge.
              </p>
              <p>
                My ultimate career goal is to become a <strong className="text-white font-medium">Full Stack Developer</strong>. 
                I enjoy the process of bringing ideas to life, from crafting beautiful user interfaces to building robust backend logic.
              </p>
            </motion.div>
            
            <motion.div variants={itemVariants} className="bg-white/5 border border-white/10 rounded-2xl p-8 relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl -mr-10 -mt-10 transition-transform group-hover:scale-150 duration-700" />
              <h3 className="text-xl font-semibold mb-6 flex items-center gap-2">
                <Briefcase className="w-5 h-5 text-indigo-400" />
                Career Goal
              </h3>
              <div className="text-4xl font-bold tracking-tight text-transparent bg-clip-text bg-gradient-to-br from-white to-gray-500 mb-4">
                Full Stack<br />Developer
              </div>
              <p className="text-gray-400 text-sm font-mono">
                Building end-to-end web solutions.
              </p>
            </motion.div>
          </div>
        </motion.section>

        {/* Skills Section */}
        <motion.section 
          id="skills" 
          className="py-24 border-t border-white/5"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={containerVariants}
        >
          <motion.div variants={itemVariants} className="flex items-center gap-4 mb-12">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/20 flex items-center justify-center text-emerald-400">
              <Terminal className="w-6 h-6" />
            </div>
            <h2 className="text-3xl font-bold">Technical Skills</h2>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6">
            {/* Programming */}
            <motion.div variants={itemVariants} className="bg-white/5 border border-white/10 rounded-2xl p-6 hover:-translate-y-2 hover:bg-white/[0.07] hover:border-orange-500/30 hover:shadow-[0_10px_30px_rgba(249,115,22,0.15)] transition-all duration-300 group">
              <div className="w-10 h-10 rounded-lg bg-orange-500/20 flex items-center justify-center text-orange-400 mb-6 group-hover:scale-110 transition-transform duration-300">
                <Coffee className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-semibold mb-4 group-hover:text-orange-400 transition-colors">Programming</h3>
              <ul className="space-y-3">
                <li className="flex items-center gap-3 text-gray-300">
                  <span className="w-2 h-2 rounded-full bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.8)]" />
                  Java
                </li>
              </ul>
            </motion.div>

            {/* Web Development */}
            <motion.div variants={itemVariants} className="bg-white/5 border border-white/10 rounded-2xl p-6 hover:-translate-y-2 hover:bg-white/[0.07] hover:border-blue-500/30 hover:shadow-[0_10px_30px_rgba(59,130,246,0.15)] transition-all duration-300 group">
              <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center text-blue-400 mb-6 group-hover:scale-110 transition-transform duration-300">
                <Monitor className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-semibold mb-4 group-hover:text-blue-400 transition-colors">Web Development</h3>
              <ul className="space-y-3">
                <li className="flex items-center gap-3 text-gray-300">
                  <span className="w-2 h-2 rounded-full bg-orange-600 shadow-[0_0_8px_rgba(234,88,12,0.8)]" />
                  HTML
                </li>
                <li className="flex items-center gap-3 text-gray-300">
                  <span className="w-2 h-2 rounded-full bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.8)]" />
                  CSS
                </li>
              </ul>
            </motion.div>

            {/* Tools */}
            <motion.div variants={itemVariants} className="bg-white/5 border border-white/10 rounded-2xl p-6 hover:-translate-y-2 hover:bg-white/[0.07] hover:border-cyan-500/30 hover:shadow-[0_10px_30px_rgba(6,182,212,0.15)] transition-all duration-300 group">
              <div className="w-10 h-10 rounded-lg bg-cyan-500/20 flex items-center justify-center text-cyan-400 mb-6 group-hover:scale-110 transition-transform duration-300">
                <Wrench className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-semibold mb-4 group-hover:text-cyan-400 transition-colors">Tools</h3>
              <ul className="space-y-3">
                <li className="flex items-center gap-3 text-gray-300">
                  <span className="w-2 h-2 rounded-full bg-cyan-500 shadow-[0_0_8px_rgba(6,182,212,0.8)]" />
                  VS Code
                </li>
              </ul>
            </motion.div>
          </div>
        </motion.section>

        {/* Education Section */}
        <motion.section 
          id="education" 
          className="py-24 border-t border-white/5"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={containerVariants}
        >
          <motion.div variants={itemVariants} className="flex items-center gap-4 mb-12">
            <div className="w-12 h-12 rounded-xl bg-purple-500/20 flex items-center justify-center text-purple-400">
              <GraduationCap className="w-6 h-6" />
            </div>
            <h2 className="text-3xl font-bold">Education</h2>
          </motion.div>

          <motion.div variants={itemVariants} className="relative pl-8 md:pl-0">
            {/* Timeline Line (Mobile only) */}
            <div className="absolute left-[11px] top-0 bottom-0 w-px bg-white/10 md:hidden" />
            
            <div className="relative bg-white/5 border border-white/10 rounded-2xl p-8 md:p-10 hover:-translate-y-2 hover:border-purple-500/50 hover:shadow-[0_10px_40px_rgba(168,85,247,0.15)] hover:bg-white/[0.08] transition-all duration-300 group">
              {/* Timeline Dot (Mobile only) */}
              <div className="absolute left-[-33px] top-10 w-4 h-4 rounded-full bg-purple-500 border-4 border-gray-950 md:hidden" />
              
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div>
                  <div className="text-purple-400 font-mono text-sm mb-2">Currently Enrolled</div>
                  <h3 className="text-2xl font-bold mb-2">Bachelor of Computer Applications (BCA)</h3>
                  <p className="text-xl text-gray-400">2nd Year</p>
                </div>
                <div className="md:text-right">
                  <div className="flex items-center gap-2 text-gray-300 font-medium md:justify-end mb-2">
                    <GraduationCap className="w-5 h-5" />
                    SSISM Sandalpur
                  </div>
                  <div className="text-gray-500 text-sm font-mono">Madhya Pradesh</div>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.section>

        {/* Contact Section */}
        <motion.section 
          id="contact" 
          className="py-24 border-t border-white/5"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={containerVariants}
        >
          <motion.div variants={itemVariants} className="flex items-center gap-4 mb-12">
            <div className="w-12 h-12 rounded-xl bg-cyan-500/20 flex items-center justify-center text-cyan-400">
              <Mail className="w-6 h-6" />
            </div>
            <h2 className="text-3xl font-bold">Get In Touch</h2>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Info */}
            <motion.div variants={itemVariants} className="space-y-8">
              <div className="space-y-4">
                <h3 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-400">Let's work together</h3>
                <p className="text-gray-400 text-lg leading-relaxed">
                  I'm currently looking for new opportunities and collaborations. 
                  Whether you have a question or just want to say hi, I'll try my best to get back to you!
                </p>
              </div>

              <div className="grid gap-4">
                <a 
                  href="mailto:amanbadodiya.in@gmail.com"
                  className="group p-6 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/10 hover:border-emerald-500/50 transition-all duration-300 flex items-center gap-4"
                >
                  <div className="w-12 h-12 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform duration-300">
                    <Mail className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold">Email Me</h4>
                    <p className="text-gray-400 text-sm font-mono">amanbadodiya.in@gmail.com</p>
                  </div>
                </a>

                <a 
                  href="https://linkedin.com/in/amanbadodiya"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group p-6 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/10 hover:border-blue-500/50 transition-all duration-300 flex items-center gap-4"
                >
                  <div className="w-12 h-12 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400 group-hover:scale-110 transition-transform duration-300">
                    <Linkedin className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold">LinkedIn</h4>
                    <p className="text-gray-400 text-sm font-mono">amanbadodiya</p>
                  </div>
                </a>
              </div>
            </motion.div>

            {/* Contact Form */}
            <motion.div variants={itemVariants} className="bg-white/5 border border-white/10 rounded-3xl p-8 relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full blur-3xl -mr-10 -mt-10" />
              
              <form 
                action="https://formspree.io/f/amanbadodiya.in@gmail.com" 
                method="POST"
                className="space-y-6 relative z-10"
              >
                <div className="space-y-2">
                  <label className="text-sm font-mono text-gray-400 ml-1">Your Name</label>
                  <div className="relative">
                    <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                    <input 
                      type="text" 
                      name="name"
                      required
                      placeholder="John Doe"
                      className="w-full bg-gray-950/50 border border-white/10 rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500/50 transition-all"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-mono text-gray-400 ml-1">Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                    <input 
                      type="email" 
                      name="email"
                      required
                      placeholder="john@example.com"
                      className="w-full bg-gray-950/50 border border-white/10 rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500/50 transition-all"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-mono text-gray-400 ml-1">Message</label>
                  <div className="relative">
                    <MessageSquare className="absolute left-4 top-4 w-5 h-5 text-gray-500" />
                    <textarea 
                      name="message"
                      required
                      rows={4}
                      placeholder="How can I help you?"
                      className="w-full bg-gray-950/50 border border-white/10 rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500/50 transition-all resize-none"
                    />
                  </div>
                </div>

                <button 
                  type="submit"
                  className="w-full py-4 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 text-gray-950 font-bold flex items-center justify-center gap-2 hover:scale-[1.02] active:scale-[0.98] transition-all shadow-[0_0_20px_rgba(52,211,153,0.3)]"
                >
                  <Send className="w-5 h-5" />
                  Send Message
                </button>
              </form>
            </motion.div>
          </div>
        </motion.section>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/5 py-12 text-center text-gray-500 font-mono text-sm">
        <p>Built with React & Tailwind CSS</p>
        <p className="mt-2">© {new Date().getFullYear()} Aman Badodiya. All rights reserved.</p>
      </footer>
    </div>
  );
}
