import createGlobe from "cobe";
import { useEffect, useRef } from "react";

export default function Globe() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    let phi = 0;
    
    if (!canvasRef.current) return;
    
    const globe = createGlobe(canvasRef.current, {
      devicePixelRatio: 2,
      width: 1000,
      height: 1000,
      phi: 0,
      theta: 0.2,
      dark: 1,
      diffuse: 1.2,
      mapSamples: 20000,
      mapBrightness: 6,
      baseColor: [0.05, 0.05, 0.05], // Black/Dark Earth
      markerColor: [0.1, 0.8, 0.5], // Emerald marker
      glowColor: [0.02, 0.02, 0.02], // Very subtle glow
      markers: [
        { location: [22.8, 77.0], size: 0.08 } // Approx MP, India
      ],
      onRender: (state) => {
        state.phi = phi;
        phi += 0.003; // Slow rotation
      },
    });
    
    return () => {
      globe.destroy();
    }
  }, []);

  return (
    <div className="w-full max-w-[500px] aspect-square mx-auto relative z-10">
      <canvas
        ref={canvasRef}
        className="w-full h-full opacity-90 cursor-move"
        style={{ contain: 'layout paint size' }}
      />
    </div>
  );
}
